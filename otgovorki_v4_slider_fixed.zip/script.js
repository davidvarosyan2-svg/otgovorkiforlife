const excuses = {"💼 ОПОЗДАЛ НА РАБОТУ":["Утром пришлось срочно вернуться домой — забыл важный документ/телефон/кошелёк.","Долго ждал автобус, приложение показывало, что транспорт рядом, но он приехал очень поздно.","По дороге попал в сильную пробку из-за аварии, поэтому приехал позже, чем рассчитывал.","Утром неожиданно разболелась голова, пришлось выпить таблетку. Когда она начала действовать, сразу выехал.","Утром пришлось задержаться, потому что дома отключили воду, и я ждал, пока всё восстановится.","Дверь захлопнулась, а ключи остались внутри. Пришлось ждать, пока мне помогут попасть домой.","Мои рабочие материалы остались в другом месте, поэтому пришлось заехать и забрать их.","Лифт сломался, пришлось ждать специалистов.","Питомцу стало плохо, пришлось срочно отвезти его к ветеринару.","Мой смартфон вышел из строя, пришлось срочно решать вопрос с телефоном."],"👥 НЕ ХОЧУ ГУЛЯТЬ С ДРУЗЬЯМИ":["Сегодня к нам приезжают родственники.","Я уже пообещал девушке провести этот вечер с ней.","Отец/мама попросили остаться дома и помочь.","Я очень устал за день, хочу просто лечь спать пораньше.","Завал по учёбе, нужно срочно доделать проект.","Завал по работе, нужно срочно закончить проект.","Сегодня неважно себя чувствую, поэтому хочу остаться дома.","Сегодня хочу заняться своим любимым хобби.","Я сейчас не хочу никуда идти, хочу просто побыть дома.","Меня срочно вызвали по делам, поэтому сегодня не получится."],"🎓 ОПОЗДАЛ НА УЧЁБУ":["Проспал будильник и не услышал его.","Утром пришлось вернуться домой за важной вещью.","Автобус долго не приезжал, хотя приложение показывало, что он уже рядом.","По дороге попал в пробку из-за аварии.","Утром плохо себя чувствовал, поэтому пришлось немного подождать.","Перед парой пришлось срочно заехать в одно место.","Не смог найти ключи перед выходом и потратил на это много времени.","Перед выходом пришлось срочно распечатать материалы для пары.","Я вышел вовремя, но пришлось вернуться домой — забыл ноутбук.","Будильник не сработал, поэтому я проспал и опоздал на пару."],"📚 НЕ СДАЛ ПРОЕКТ ВОВРЕМЯ":["Почти закончил проект, но при финальной проверке обнаружил несколько ошибок.","Файл с проектом повредился, пришлось восстанавливать последнюю версию.","Компьютер начал зависать во время работы, из-за этого потерял много времени.","Неправильно понял требования к проекту и большую часть пришлось переделать.","Я недооценил объём работы и понял слишком поздно, что не успеваю.","Во время подготовки проекта возникли проблемы с программой.","Я закончил основную часть вовремя, но не успел нормально оформить проект.","Исходные данные для проекта были неполными, пришлось всё перепроверить.","Перед отправкой обнаружил, что несколько страниц отображаются неправильно.","Я случайно начал работать не в той версии файла и заметил это под конец."],"📱 НЕ ВЗЯЛ ТРУБКУ У МАМЫ/ПАПЫ":["Телефон был на беззвучном, поэтому я не услышал звонок.","Телефон разрядился, только сейчас смог его включить.","Я был в душе и не услышал телефон.","Телефон остался в другой комнате, поэтому я не видел звонков.","Был в шумном месте и вообще не услышал, что мне звонили.","Я был за рулём и не мог взять трубку.","Был на занятии/встрече, поэтому не мог ответить.","Телефон завис, и я не сразу увидел пропущенные.","Я увидел звонки, но был занят и хотел перезвонить позже.","Я оставил телефон в машине и заметил это только позже."],"💼 ВООБЩЕ НЕ ПРИШЁЛ НА РАБОТУ":["Моему питомцу нужна срочная помощь, и я должен остаться с ним.","У меня произошла авария в доме, и мне нужно разбираться с этой ситуацией.","Мой автомобиль сломался, и я не могу доехать до работы.","Съел что-то не то, сижу дома, на работу приехать не смогу.","Ужасно болит голова, поэтому сегодня останусь дома.","У меня произошла проблема с квартирой, и я жду специалиста.","Ночью прорвало трубу в квартире, утром пришлось ждать аварийную службу.","Мне пришлось срочно ехать в больницу с близким человеком.","Утром меня вызвали для срочного решения семейного вопроса.","Сегодня нужно срочно решать вопрос с документами, и всё заняло целый день."],"💔 РАССТАТЬСЯ":["Я понял, что мои чувства уже не такие, как раньше.","Мне кажется, мы стали слишком разными.","Я понял, что сейчас не готов к серьёзным отношениям.","Мне нужно время разобраться в себе и своих мыслях.","Я чувствую, что наши отношения больше не делают нас обоих счастливыми.","Между нами стало слишком много недопонимания и ссор.","Я понял, что мы хотим от отношений совершенно разных вещей.","Мне кажется, мы больше держимся за привычку, чем за настоящие чувства.","Я больше не чувствую той связи между нами, которая была раньше.","Я не хочу тебя обманывать — мои чувства изменились."]};

const styles = [
  {id:'realistic', icon:'🧠', name:'Правдоподобная'},
  {id:'funny', icon:'😂', name:'Смешная'},
  {id:'dramatic', icon:'😈', name:'Пафосная'},
  {id:'sad', icon:'🥺', name:'Жалостливая'}
];
const modifiers = {
  realistic: {prefix:'', suffix:''}, funny:{prefix:'',suffix:' Ну, звучит убедительно… наверное 😅'},
  dramatic:{prefix:'В связи с обстоятельствами, ',suffix:''}, sad:{prefix:'Мне правда неловко это говорить, но ',suffix:''}
};

const categoryMenu=document.getElementById('categoryMenu'), categoryScroller=document.getElementById('categoryScroller'), categoryPrev=document.getElementById('categoryPrev'), categoryNext=document.getElementById('categoryNext'), categoryThumb=document.getElementById('categoryThumb'), generateButton=document.getElementById('generateButton'), result=document.getElementById('result'), excuseText=document.getElementById('excuseText'), anotherButton=document.getElementById('anotherButton');
const categories=Object.keys(excuses); let currentCategory=categories[0], currentStyle='realistic', lastIndex=-1, favorites=JSON.parse(localStorage.getItem('otgovorkiFavorites')||'[]');
const styleMenu=document.createElement('div'); styleMenu.className='style-menu'; categoryMenu.parentElement.after(styleMenu);
const favoriteButton=document.createElement('button'); favoriteButton.className='favorite-button'; favoriteButton.type='button'; favoriteButton.innerHTML='♡';
const metrics=document.createElement('div'); metrics.className='metrics';
const loading=document.createElement('div'); loading.className='loading hidden';
loading.innerHTML='<div class="loading-stage"><span id="loadIcon">🔍</span><span id="loadText">Анализирую ситуацию...</span></div><div class="progress"><span></span></div><div class="load-sub" id="loadSub">Подбираю идеальную отговорку...</div>';
result.insertBefore(loading,result.firstChild); result.querySelector('.excuse').before(favoriteButton); result.querySelector('.copy-hint').before(metrics);

function renderMenu(){ categoryMenu.innerHTML=''; categories.forEach(c=>{const b=document.createElement('button');b.type='button';b.className='option'+(c===currentCategory?' active':'');b.textContent=c;b.onclick=()=>{currentCategory=c;lastIndex=-1;hideResult();renderMenu();};categoryMenu.appendChild(b);}); renderStyles(); }
function renderStyles(){styleMenu.innerHTML='';styles.forEach(s=>{const b=document.createElement('button');b.className='style-pill'+(s.id===currentStyle?' active':'');b.innerHTML=`${s.icon} ${s.name}`;b.onclick=()=>{currentStyle=s.id;renderStyles();};styleMenu.appendChild(b);});}
function hideResult(){result.classList.add('hidden');generateButton.classList.remove('hidden');}
function pick(){const list=excuses[currentCategory];let i=Math.floor(Math.random()*list.length);if(list.length>1)while(i===lastIndex)i=Math.floor(Math.random()*list.length);lastIndex=i;return list[i];}
function metricsFor(text){let funny=25+Math.floor(Math.random()*55), path=25+Math.floor(Math.random()*60), believable=40+Math.floor(Math.random()*55); if(currentStyle==='funny')funny=Math.max(funny,78);if(currentStyle==='dramatic')path=Math.max(path,82);if(currentStyle==='realistic')believable=Math.max(believable,82);return {funny,path,believable};}
function setLoadingStage(sec){const data=sec===0?['🔍','Анализирую ситуацию...','Смотрю на выбранную категорию...']:sec===1?['🧠','Подбираю подходящий вариант...','Сверяю тон и ситуацию...']:sec===2?['🎭','Настраиваю стиль...','Добавляю нужное настроение...']:['✨','Готово!','Отговорка почти готова...'];document.getElementById('loadIcon').textContent=data[0];document.getElementById('loadText').textContent=data[1];document.getElementById('loadSub').textContent=data[2];}
function generateAnswer(){if(generateButton.disabled)return; generateButton.disabled=true; anotherButton.disabled=true; result.classList.remove('hidden'); excuseText.classList.add('generating'); excuseText.textContent=''; favoriteButton.classList.remove('saved'); loading.classList.remove('hidden'); favoriteButton.classList.add('hidden');metrics.classList.add('hidden');setLoadingStage(0);generateButton.classList.add('hidden'); const started=Date.now(); [1,2,3].forEach((sec)=>setTimeout(()=>setLoadingStage(sec),sec*1000)); setTimeout(()=>{const base=pick(), m=modifiers[currentStyle];const final=m.prefix+base+m.suffix;loading.classList.add('hidden');excuseText.classList.remove('generating');excuseText.classList.add('type-in');typeText(final,()=>{const vals=metricsFor(final);metrics.innerHTML=`<span>🎩 Пафосность <b>${vals.path}%</b></span><span>🧠 Правдоподобность <b>${vals.believable}%</b></span><span>😂 Смешность <b>${vals.funny}%</b></span>`;metrics.classList.remove('hidden');favoriteButton.classList.remove('hidden');updateFavorite(final);generateButton.disabled=false;anotherButton.disabled=false;});},Math.max(4000,4000-(Date.now()-started)));}
function typeText(text,done){excuseText.textContent='';let i=0;const step=()=>{if(i<text.length){excuseText.textContent+=text[i++];setTimeout(step,Math.max(12,32-(text.length>100?8:0)));}else{excuseText.classList.remove('type-in');done();}};step();}
function updateFavorite(text){favoriteButton.classList.toggle('saved',favorites.includes(text));favoriteButton.innerHTML=favorites.includes(text)?'♥':'♡';favoriteButton.title=favorites.includes(text)?'Убрать из избранного':'Добавить в избранное';}
function toggleFavorite(){const text=excuseText.textContent.trim();if(!text)return;const i=favorites.indexOf(text);if(i>=0)favorites.splice(i,1);else favorites.unshift(text);localStorage.setItem('otgovorkiFavorites',JSON.stringify(favorites.slice(0,50)));updateFavorite(text);favoriteButton.animate([{transform:'scale(1)'},{transform:'scale(1.25)'},{transform:'scale(1)'}],{duration:350});}

generateButton.onclick=generateAnswer;anotherButton.onclick=generateAnswer;favoriteButton.onclick=toggleFavorite;
excuseText.onclick=async()=>{const text=excuseText.textContent.trim();if(!text||loading.classList.contains('hidden')===false)return;try{await navigator.clipboard.writeText(text);}catch(e){const t=document.createElement('textarea');t.value=text;document.body.appendChild(t);t.select();document.execCommand('copy');t.remove();}excuseText.classList.remove('copied-state');void excuseText.offsetWidth;excuseText.classList.add('copied-state');const hint=document.querySelector('.copy-hint');hint.textContent='✓ Скопировано';setTimeout(()=>hint.textContent='Нажми на текст, чтобы скопировать',1200);};

renderMenu();

function scrollCategories(direction){
  const step = Math.max(160, categoryScroller.clientWidth * 0.7);
  categoryScroller.scrollBy({left: direction * step, behavior:'smooth'});
}

function updateCategorySlider(){
  const max = Math.max(0, categoryScroller.scrollWidth - categoryScroller.clientWidth);
  if(max <= 1){
    categoryThumb.style.width='100%';
    categoryThumb.style.left='0';
    categoryThumb.style.opacity='.35';
    categoryPrev.disabled=true;
    categoryNext.disabled=true;
    return;
  }
  categoryThumb.style.opacity='1';
  const visibleRatio = Math.min(1, categoryScroller.clientWidth / categoryScroller.scrollWidth);
  const thumbWidth = Math.max(18, visibleRatio * 100);
  const maxThumbTravel = 100 - thumbWidth;
  const ratio = categoryScroller.scrollLeft / max;
  categoryThumb.style.width = thumbWidth + '%';
  categoryThumb.style.left = (ratio * maxThumbTravel) + '%';
  categoryPrev.disabled = categoryScroller.scrollLeft <= 1;
  categoryNext.disabled = categoryScroller.scrollLeft >= max - 1;
}

categoryPrev.addEventListener('click',()=>scrollCategories(-1));
categoryNext.addEventListener('click',()=>scrollCategories(1));
categoryScroller.addEventListener('scroll',updateCategorySlider,{passive:true});
window.addEventListener('resize',updateCategorySlider);

let draggingThumb=false;
const scrollbar=document.querySelector('.category-scrollbar');

function setCategoryFromPointer(e){
  const r=scrollbar.getBoundingClientRect();
  const maxScroll=Math.max(0,categoryScroller.scrollWidth-categoryScroller.clientWidth);
  const thumbRatio=Math.min(1, categoryScroller.clientWidth/categoryScroller.scrollWidth);
  const thumbWidthPx=Math.max(28, r.width*thumbRatio);
  const usable=Math.max(1,r.width-thumbWidthPx);
  const x=Math.max(0,Math.min(usable,e.clientX-r.left-thumbWidthPx/2));
  categoryScroller.scrollLeft=(x/usable)*maxScroll;
}

scrollbar.addEventListener('pointerdown',(e)=>{
  draggingThumb=true;
  scrollbar.setPointerCapture(e.pointerId);
  setCategoryFromPointer(e);
});
scrollbar.addEventListener('pointermove',(e)=>{
  if(draggingThumb) setCategoryFromPointer(e);
});
scrollbar.addEventListener('pointerup',()=>draggingThumb=false);
scrollbar.addEventListener('pointercancel',()=>draggingThumb=false);

categoryScroller.addEventListener('wheel',(e)=>{
  if(Math.abs(e.deltaY)>Math.abs(e.deltaX)){
    e.preventDefault();
    categoryScroller.scrollLeft += e.deltaY;
  }
},{passive:false});

updateCategorySlider();
